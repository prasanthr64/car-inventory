<?php  
 //upload.php  
 $output = '';  
 if(is_array($_FILES))   
 {  
$i=0;
      foreach ($_FILES['files']['name'] as $name => $value)  
      {  
           $file_name = explode(".", $_FILES['files']['name'][$name]);  
           $allowed_ext = array("jpg", "jpeg", "png", "gif");  
           if(in_array($file_name[1], $allowed_ext))  
           {  
                $new_name = md5(rand()) . '.' . $file_name[1];  
                $sourcePath = $_FILES['files']['tmp_name'][$name];  
               // $targetPath = "upload/".$new_name;  
			   $targetPath = "upload/".$file_name[0].'.'.$file_name[1];
                if(move_uploaded_file($sourcePath, $targetPath))  
                {  
					if($i==0){
                     $output .= '<img src="'.$targetPath.'" width="150px" height="180px" />'; 
						$output .= '<input type="hidden" name="pic_1_name" id="pic_1_name" value="'.$file_name[0].'.'.$file_name[1].'" />'; 
					}else if($i==1){
                     $output .= '<img src="'.$targetPath.'" width="150px" height="180px" />'; 
						$output .= '<input type="hidden" name="pic_2_name" id="pic_2_name" value="'.$file_name[0].'.'.$file_name[1].'" />'; 
					}
					
                }                 
           } 
$i++;           
      }  
      echo $output;  
 }  
 ?> 
 