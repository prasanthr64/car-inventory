<!DOCTYPE html>
<html lang="en">
<head>
<title>Car Inventory</title>
<meta charset="utf-8">
<!---- <meta name="viewport" content="width=device-width, initial-scale=1"> ---->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
</head>
<body>
<nav class="navbar diamond-nav">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="nav-item"><a href="index.php" class="nav-link active">Manufacturer Management</a></li>
        <li class="nav-item"><a href="model-management.php" class="nav-link">Model Management</a></li>
       <li class="nav-item"><a href="view-inventory.php" class="nav-link">View Inventory</a></li>
      </ul>
    </div>
  </div>
</nav>
</header>

<!----------main content------------>
<article id="projects-listing-section">
  <section class="projdetails sd-about" id="overview">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="custom-heading section-heading sd-txt-center">
            <h1>Inventory Management</h1>
          </div>
          
        </div>
        
      </div>
      <div class="row">
		<div class="col-md-12 ">
			<div class="sd-contact-form">
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th scope="col">Serial Number</th>
								<th scope="col">Manufacturer Name</th>
								<th scope="col">Model Name</th>
								<th scope="col">Transmission Type</th>
								<th scope="col">Fuel Type</th>
								<th scope="col">New/Used</th>
								<th scope="col">Exterior Color</th>
								<th scope="col">Interior Color</th>
								<th scope="col">Manufacturing Year</th>
								<th scope="col">Registration Number</th>
								<th scope="col">Additional Information</th>
								<th scope="col">Image 1</th>
								<th scope="col">Image 2</th>
								<th scope="col"></th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$servername = "servername";
				$username = "db_username";
				$password = "db_password";
				$dbname = "db_name";

								// Create connection
								$conn = new mysqli($servername, $username, $password, $dbname);
								// Check connection
								if ($conn->connect_error) 
								{
									die("<p style='text-align:center;color:#000;'>Error occured.Please try again after sometime</p>");
								} 
								else
								{
									//$inert_dta="INSERT INTO manufacturer (Manufacturer_list) VALUES ('prasanth')"; 
									$manu_list="SELECT * FROM car_details";
									//$sql_edit = "SELECT * FROM kau_registrants WHERE id='$new_user_id' ";				
									$result_edit = $conn->query($manu_list);
									$car_detail=array();
									if ($result_edit->num_rows > 0) 
									{
										$cnt=1;
										// output data of each row
										while($row_edit = $result_edit->fetch_assoc()) { ?>
											<tr>
												<form method="post" action="" >
													<input type="hidden" name="model_id" value="<?php echo $row_edit['ID']; ?>" >
													<th scope="row"><?php echo $cnt; ?></th>
													<td><?php echo $row_edit['manufacturer_name']; ?></td>
													<td><?php echo $row_edit['model_name']; ?></td>
													<td><?php echo $row_edit['transmission_type']; ?></td>
													<td><?php echo $row_edit['fuel_type']; ?></td>
													<td><?php echo $row_edit['car_type']; ?></td>
													<td><?php echo $row_edit['exterior_color']; ?></td>
													<td><?php echo $row_edit['interior_color']; ?></td>
													<td><?php echo $row_edit['manufacturing_year']; ?></td>
													<td><?php echo $row_edit['registration_number']; ?></td>
													<td><?php echo $row_edit['notes']; ?></td>
													<td><img src="<?php echo $row_edit['pic_1_url']; ?>" class="img-responsive" style="max-width:150px;" /></td>
													<td><img src="<?php echo $row_edit['pic_2_url']; ?>" class="img-responsive" style="max-width:150px;" /></td>
													<td><button class="sd-btn1" type="submit" name="car_sold1">Sold</button> </td>
												</form>
											</tr>
											<?php
											$cnt++;
										}
									}	
								}
							?>
						</tbody>
					</table>
				</div>
            </div>
		</div>
    </div>
	  <?php 
	    if(isset($_POST['car_sold1']))
			{
				$entry_id=$_POST['model_id'];
				$servername = "servername";
				$username = "db_username";
				$password = "db_password";
				$dbname = "db_name";

				// Create connection
				$conn = new mysqli($servername, $username, $password, $dbname);
				// Check connection
				if ($conn->connect_error) 
					{
						die("<p style='text-align:center;color:#000;'>Error occured.Please try again after sometime</p>");
					} 
					else
					{
						
						$delt_dta="DELETE FROM car_details WHERE ID='$entry_id'";
						if($conn->query($delt_dta) == TRUE){ ?>
						<script>
							alert("Record deleted successfully");
							exit;
						</script>
						<?php }else{ ?>
						<script>
							alert("Record not deleted successfully");
						</script>
						<?php } 
						
					}
			}
		?>
    </div>
  </section>
</article>
<!----------main content---------------->

<!---------------footer------------------>

<div class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12">
        <p>Designed & Developed By <a target="_blank" href="#">Prasanth</a></p>
      </div>
    </div>
  </div>
</div>

<script src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/custom.js"></script>
</body>
</html>
