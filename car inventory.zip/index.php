<!DOCTYPE html>
<html lang="en">
<head>
<title>Car Inventory</title>
<meta charset="utf-8">
<!---- <meta name="viewport" content="width=device-width, initial-scale=1"> ---->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">
</head>
<body>
<nav class="navbar diamond-nav">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="nav-item"><a href="index.php" class="nav-link active">Manufacturer Management</a></li>
        <li class="nav-item"><a href="model-management.php" class="nav-link">Model Management</a></li>
       <li class="nav-item"><a href="view-inventory.php" class="nav-link">View Inventory</a></li>
      </ul>
    </div>
  </div>
</nav>
</header>


<!----------main content------------>
<article id="projects-listing-section">
  <section class="projdetails sd-about" id="overview">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="custom-heading section-heading sd-txt-center">
            <h1>Manufacturer Management</h1>
          </div>
        </div>
      </div>
      <div class="row">
		<div class="col-md-12 ">
			<div class="sd-contact-form">
	   
			<?php 
				if(isset($_POST['add_manufacturer']))
				{
					$manufact_name=$_POST['manu_name'];
					$servername = "servername";
					$username = "db_username";
					$password = "db_password";
					$dbname = "db_name";

					// Create connection
					$conn = new mysqli($servername, $username, $password, $dbname);
					// Check connection
					if ($conn->connect_error) 
					{
						die("<p style='text-align:center;color:#000;'>Error occured.Please try again after sometime</p>");
					} 
					else
					{
						
						//$inert_dta="INSERT INTO manufacturer (Manufacturer_list) VALUES ('prasanth')"; 
						$inert_dta="INSERT INTO manufacturer(Manufacturer_list) VALUES ('$manufact_name')";
						if($conn->query($inert_dta) == TRUE){
							echo "Manufacturer name updated successfully";
						}else{
							echo "Manufacturer name not updated successfully";
						}
						
					}
				}
			?>
       
				<form  method="post" action="" class="sd-form-inner">
					<div class="row">
						<div class="form-group col-md-6"> 
							<input type="text" name="manu_name" class="form-control" id="txt" placeholder="Manufacturer Name">
						</div>
						<div class="form-group col-md-6">
							<button class="sd-btn1" type="submit" name="add_manufacturer">Add manufacture</button> 
						</div>
					</div> 
				</form>
            </div>
       </div>
      </div>
    </div>
  </section>
</article>
<!----------main content---------------->

<!---------------footer------------------>

<div class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12">
        <p>Designed & Developed By <a target="_blank" href="#">Prasanth</a></p>
      </div>
    </div>
  </div>
</div>

<script src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/custom.js"></script>
</body>
</html>
