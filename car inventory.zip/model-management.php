<!DOCTYPE html>
<html lang="en">
<head>
<title>Car Inventory</title>
<meta charset="utf-8">
<!---- <meta name="viewport" content="width=device-width, initial-scale=1"> ---->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700" rel="stylesheet">


</head>
<body>
<nav class="navbar diamond-nav">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="nav-item"><a href="index.php" class="nav-link">Manufacturer Management</a></li>
        <li class="nav-item"><a href="model-management.php" class="nav-link active">Model Management</a></li>
       <li class="nav-item"><a href="view-inventory.php" class="nav-link">View Inventory</a></li>
      </ul>
    </div>
  </div>
</nav>
</header>

		<?php
			$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
			$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
			$path_parts = pathinfo($url);
			$dir_url=$path_parts['dirname'];
		?>

<!----------main content------------>
<article id="projects-listing-section">
  <section class="projdetails sd-about" id="overview">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
			<div class="custom-heading section-heading sd-txt-center">
				<h1>Model Management</h1>
			</div>
        </div>   
		</div>
			<div class="row">
				<div class="col-md-12 ">
					<div class="sd-contact-form">
						<?php 
							if(isset($_POST['add_car_detail']))
								{
									$model_name=$_POST['model_name'];
									$manufact_name=$_POST['manu_name'];
									$fuel_type=$_POST['fuel_type'];
									$transmission_type=$_POST['transmison_type'];
									$car_type=$_POST['car_type'];
									$extr_colr=$_POST['exter_colr'];
									$intr_colr=$_POST['inter_colr'];
									$manufact_year=$_POST['manufact_year'];
									$reg_no=$_POST['reg_no'];
									$notes=$_POST['notes'];
									$pic_1_url=$_POST['pic_1_name'];
									$pic_2_url=$_POST['pic_2_name'];
									$image_1_url=$dir_url.'/upload/'.$pic_1_url;
									$image_2_url=$dir_url.'/upload/'.$pic_2_url;
				
									$servername = "servername";
									$username = "db_username";
									$password = "db_password";
									$dbname = "db_name";

									// Create connection
									$conn = new mysqli($servername, $username, $password, $dbname);
									// Check connection
									if ($conn->connect_error) 
										{
											die("<p style='text-align:center;color:#000;'>Error occured.Please try again after sometime</p>");
										} 
									else
										{
						
											//$inert_dta="INSERT INTO manufacturer (Manufacturer_list) VALUES ('prasanth')"; 
											$inert_car_dta="INSERT INTO car_details(model_name,manufacturer_name,fuel_type,transmission_type,car_type,exterior_color,interior_color,manufacturing_year,registration_number,notes,pic_1_url,pic_2_url) 
											VALUES ('$model_name','$manufact_name','$fuel_type','$transmission_type','$car_type','$extr_colr','$intr_colr','$manufact_year','$reg_no','$notes','$image_1_url','$image_2_url')";
											if($conn->query($inert_car_dta) == TRUE){
												$data_upd_sts="Data's updated successfully";
											}else{
												$data_upd_sts= "Data's not updated successfully";
											}	
										}
								}
							?>
       
					<div class="row">
						<div class="form-group col-md-12">
							<p style="color:red;"><?php echo $data_upd_sts; ?></p>
							<form id="uploadForm" action="upload.php" method="post">  
                       
								<div class="col-md-4" align="right">  
									<label>Upload 2 Images of car</label>  
								</div>  
								<div class="col-md-4">  
									<input name="files[]" type="file" multiple />  
								</div>  
								 <div class="col-md-4">  
									  <input type="submit" value="Submit" />  
								 </div>  
								<div style="clear:both"></div>  
							</form>  
						</div>
					</div>
				
				<form  method="post" action="" class="sd-form-inner">
					<div class="row">
						<div class="form-group col-md-12">
							<div id="gallery"></div><div style="clear:both;"></div><br /><br />
						</div>
					</div> 
	  
	  
						<?php 
	   
							$servername = "servername";
							$username = "db_username";
							$password = "db_password";
							$dbname = "db_name";

							// Create connection
							$conn = new mysqli($servername, $username, $password, $dbname);
							// Check connection
							if ($conn->connect_error) 
							{
								die("<p style='text-align:center;color:#000;'>Error occured.Please try again after sometime</p>");
							} 
							else
							{
								
								//$inert_dta="INSERT INTO manufacturer (Manufacturer_list) VALUES ('prasanth')"; 
								$manu_list="SELECT * FROM manufacturer";
								//$sql_edit = "SELECT * FROM kau_registrants WHERE id='$new_user_id' ";				
								$result_edit = $conn->query($manu_list);
								$fevent=array();
								if ($result_edit->num_rows > 0) {
									// output data of each row
									while($row_edit = $result_edit->fetch_assoc()) {
									
									$fevent[]=$row_edit['Manufacturer_list'];
									//echo $fevent;
									}
								}
								
							}
			
						?>
	
					<div class="row">
						<div class="form-group col-md-6"> 
							<input type="text" name="model_name" class="form-control" id="txt" placeholder="Model Name">
						</div>
						<div class="form-group col-md-6">
							<select name="manu_name" class="form-control" id="manu_name">
								<option value="">----Select Manufacturer----</option>
								<?php foreach($fevent as $man_lst_valu){ ?>
								<option value="<?php echo $man_lst_valu; ?>"><?php echo $man_lst_valu; ?></option>
								<?php } ?>
							</select>
						</div>
						<p><b>Other Details</b></p>
						<div class="form-group col-md-6"> 
							<input type="text" name="fuel_type" class="form-control" id="fuel_type" placeholder="Fuel Type">
						</div>
					   <div class="form-group col-md-6">
							<input type="text" name="transmison_type" class="form-control" id="transmison_type" placeholder="Transmission Type">
					   </div>
					   <div class="form-group col-md-6"> 
							<input type="text" name="car_type" class="form-control" id="car_type" placeholder="New/Used">
					  </div>
					   <div class="form-group col-md-6">
							<input type="text" name="exter_colr" class="form-control" id="exter_colr" placeholder="Exterior Color">
					   </div>
					   <div class="form-group col-md-6"> 
							<input type="text" name="inter_colr" class="form-control" id="inter_colr" placeholder="Interior Color">
					  </div>
					   <div class="form-group col-md-6">
							<input type="text" name="manufact_year" class="form-control" id="manufact_year" placeholder="Manufacturing Year">
					   </div>
					   <div class="form-group col-md-6"> 
							<input type="text" name="reg_no" class="form-control" id="reg_no" placeholder="Registration Number">
					  </div>
					   <div class="form-group col-md-6">
							<textarea name="notes" id="notes" class="form-control" ></textarea>
					   </div>
						<div class="form-group col-md-6">
							<button class="sd-btn1" type="submit" id="add_car_detail" name="add_car_detail">Update Car details</button> 
						</div>
					</div>
               
				</form>
            </div>
       </div>
	  </div>
       
    </div>
  </section>
</article>
<!----------main content---------------->

<!---------------footer------------------>

<div class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 col-md-12">
        <p>Designed & Developed By <a target="_blank" href="#">Prasanth</a></p>
      </div>
    </div>
  </div>
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/custom.js"></script>
<script>
  $('#add_car_detail').hover(function(){
			
			if( $('#pic_1_name').val() == "" || $('#pic_2_name').val() == ""){
				
				$("#add_car_detail").attr('disabled','disabled');
			}
			else{
				$("#add_car_detail").removeAttr('disabled');
				
			}

            //alert('The file "' + fileName +  '" has been selected.');
			//alert($('#pic_1_name').val());

    });   
	
</script>
 <script>  
 $(document).ready(function(){  
      $('#uploadForm').on('submit', function(e){  
           e.preventDefault();  
           $.ajax({  
                url: "upload.php",  
                type: "POST",  
                data: new FormData(this),  
                contentType: false,  
                processData:false,  
                success: function(data)  
                {  
                     $("#gallery").html(data);  
                     alert("Image Uploaded");  
                }  
           });  
      });  
 });  
 </script> 
</body>
</html>
